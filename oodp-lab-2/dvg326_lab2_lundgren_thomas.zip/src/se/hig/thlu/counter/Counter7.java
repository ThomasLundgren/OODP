package se.hig.thlu.counter;

public class Counter7 extends SettableAbstractCounter {

	public Counter7() {
		super(7, Direction.INCREASING);
	}

}
