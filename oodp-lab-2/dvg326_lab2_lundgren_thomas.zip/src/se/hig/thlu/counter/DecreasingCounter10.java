package se.hig.thlu.counter;

class DecreasingCounter10 extends SettableAbstractCounter {

	public DecreasingCounter10() {
		super(10, Direction.DECREASING);
	}
}
