package se.hig.thlu.counter;

public interface SettableCounterType extends CounterType {

	public void setCount(int value);

}
