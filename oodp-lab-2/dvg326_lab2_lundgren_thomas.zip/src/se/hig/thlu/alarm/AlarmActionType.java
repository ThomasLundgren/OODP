package se.hig.thlu.alarm;

public interface AlarmActionType {
	public void alarmActivated();

	public void alarmDeactivated();
}
