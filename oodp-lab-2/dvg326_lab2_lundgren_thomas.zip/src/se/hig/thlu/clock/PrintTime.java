package se.hig.thlu.clock;

public enum PrintTime {
	YES, NO
}
