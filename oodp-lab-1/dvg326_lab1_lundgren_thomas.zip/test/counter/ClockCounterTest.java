package counter;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ClockCounterTest {
	
	private ClockCounter clockCounter;

	@BeforeEach
	void setUp() throws Exception {
		clockCounter = new ClockCounter();
	}

	@AfterEach
	void tearDown() throws Exception {
		clockCounter = null;
	}

	@Test
	void getTime_onNewClockCounter_returnsZero() {
		assertEquals(0, clockCounter.getTime().getSecond());
		assertEquals(0, clockCounter.getTime().getMinute());
		assertEquals(0, clockCounter.getTime().getHour());
	}
	
	@Test
	void getTime_after60Counts_returns0H1Min0Sec() {
		for (int i = 0; i < 60; i++) {
			clockCounter.count();
		}
		assertEquals(0, clockCounter.getTime().getSecond());
		assertEquals(1, clockCounter.getTime().getMinute());
		assertEquals(0, clockCounter.getTime().getHour());
	}
	
	@Test
	void getTime_afterHourCount_returns1H0Min0Sec() {
		for (int i = 0; i < 60 * 60; i++) {
			clockCounter.count();
		}
		assertEquals(0, clockCounter.getTime().getSecond());
		assertEquals(0, clockCounter.getTime().getMinute());
		assertEquals(1, clockCounter.getTime().getHour());
	}
	
	@Test
	void getTime_after24HourCount_returns0H0Min0Sec() {
		for (int i = 0; i < 24*60*60; i++) {
			clockCounter.count();
		}
		assertEquals(0, clockCounter.getTime().getSecond());
		assertEquals(0, clockCounter.getTime().getMinute());
		assertEquals(0, clockCounter.getTime().getHour());
	}
	
}
