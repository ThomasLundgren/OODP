package counter;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import counter.AbstractCounter.Direction;

class DecreasingCounter10Test {
	
	private DecreasingCounter10 decreasingCounter10;
	
	@BeforeEach
	void setUp() throws Exception {
		decreasingCounter10 = new DecreasingCounter10();
	}

	@AfterEach
	void tearDown() throws Exception {
		decreasingCounter10 = null;
	}

	@Test
	void getCount_onNewDecreasingCounter_shouldReturn10() {
		assertEquals(10, decreasingCounter10.getCount());
	}
	
	@Test
	void getCount_after9Counts_shouldReturnZero() {
		for (int i = 0; i < 9; i++) {
			decreasingCounter10.count();
		}
		assertEquals(1, decreasingCounter10.getCount());
	}
	
	@Test
	void getCount_after10Counts_shouldOverflowAndReturn9() {
		for (int i = 0; i < 10; i++) {
			decreasingCounter10.count();
		}
	}

	@Test
	void reset_afterCount_getCountReturn10() {
		decreasingCounter10.count();
		assertEquals(9, decreasingCounter10.getCount());
		decreasingCounter10.reset();
		assertEquals(10, decreasingCounter10.getCount());
	}
	
	@Test
	void pause_onCounterAtTen_shouldReturn10() {
		decreasingCounter10.pause();
		decreasingCounter10.count();
		decreasingCounter10.count();
		assertEquals(10, decreasingCounter10.getCount());
	}
	
	@Test
	void resume_afterPausingAtTen_countIncreases() {
		decreasingCounter10.pause();
		decreasingCounter10.count();
		assertEquals(10, decreasingCounter10.getCount());
		decreasingCounter10.resume();
		decreasingCounter10.count();
		assertEquals(9, decreasingCounter10.getCount());
	}
	
	@Test
	void setDirection_countUpFromNine_overflowsToTen() {
		assertEquals(10, decreasingCounter10.getCount());
		decreasingCounter10.count();
		assertEquals(9, decreasingCounter10.getCount());
		decreasingCounter10.setDirection(Direction.INCREASING);
		decreasingCounter10.count();
		assertEquals(0, decreasingCounter10.getCount());
		decreasingCounter10.count();
		assertEquals(1, decreasingCounter10.getCount());
	}
	
	@Test
	void toString_onEmptyCounter_returnsString0() {
		assertEquals("10", decreasingCounter10.toString());
	}

}
