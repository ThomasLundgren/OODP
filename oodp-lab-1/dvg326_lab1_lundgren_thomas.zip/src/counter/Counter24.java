package counter;

public class Counter24 extends AbstractCounter {

	public Counter24() {
		super(24, Direction.INCREASING);
	}

}
